import json
import math
import itertools
import networkx as nx
import matplotlib.pyplot as plt
from networkx.drawing.nx_agraph import graphviz_layout
from tabulate import tabulate
with open('gameconfig_1_34.json', 'r') as file:
        dat = json.load(file)
        
#print(dat["clientGameConfig"]["liveEvents"]["idunLiveEventConfigs"])

HSEvents = []
warpsurge = []
squigsmash = []
mowEvent = []
for event in dat["clientGameConfig"]["liveEvents"]["idunLiveEventConfigs"]:
    if event["eventType"] == "homeScreenEvent":
        HSEvents.append(event)
        if event["eventName"] == "squig_smash_tier_high":
            squigsmash.append(event)
        if event["eventName"] == "warp_surge_tier_high":
            warpsurge.append(event)
    if event["eventType"] == "mowEvent":
        mowEvent.append(event["mows"][0])
        mowEvent.append(event)

with open('live_events.json', 'w') as w:
    json.dump(dat["clientGameConfig"]["liveEvents"]["idunLiveEventConfigs"], w, indent=4)
    
with open('hs_events.json', 'w') as w:
    json.dump(HSEvents, w, indent=4)
    
with open('warp_surge.json', 'w') as w:
    json.dump(warpsurge, w, indent=4)

with open('squig_smash.json', 'w') as w:
    json.dump(squigsmash, w, indent=4)
    
with open('mow_event.json', 'w') as w:
    json.dump(mowEvent, w, indent=4)

def typeText(t):
    tt = ""
    if t == "incursionBattle":
        tt = "B"
    if t == "chest":
        tt = "C"
    if t == "incursionEnhancement":
        tt = "E"
    return tt
    
mow_dat = mowEvent[0]
path = {}
mow_dat["tiers"][0]["nodes"]

def createNodes(json_dat):
    path = {}
    labelDict = {}
    keyNodes = []
    for node in json_dat:
        path[node["index"]] = {}
        path[node["index"]]["path"] = []
        typeT = typeText(node["type"])
        path[node["index"]]["type"] = typeT
        labelDict[str(node["index"])] = node["nodeName"]
        if typeT == "B":
            path[node["index"]]["battleId"] = node["battleId"]
        if "unlockedBy" in node:
            for i in node["unlockedBy"]:
                path[i["index"]]["path"].append(node["index"])
        if not "exclusiveWith" in node:
            keyNodes.append(node["index"])
    return path, labelDict, keyNodes

def createBList(json_dat):
    blist = {}                 
    for battle in json_dat:
        blist[battle["battleId"]] = len(battle["enemies"])
    return blist

def createGraph(path, blist, labellist, title, fullPath, colourMap):
    G.clear()
    plt.clf()
    #print(path)
    #print(blist)
    print(labellist)
    for key in path:
        node = str(key)
        G.add_node(node)

    for key in path:
        for i in path[key]["path"]:
            if path[key]["type"] == "B1":
                node = str(key)
            else:    
                node = str(key)
            if path[i]["type"] == "B1":
                node2 = str(i)
            else:    
                node2 = str(i)
            G.add_edge(node, node2)
    G.edges()
    pos=graphviz_layout(G, prog='dot')
    print("---------------")
    print(pos)
    plt.figure(figsize=(10,14))
    nx.draw(G, pos, labels=labellist, with_labels=True, node_color=colourMap, node_size=600)
    plt.title(title, fontsize=20)
    fname = title + ".jpg"
    plt.savefig(fname, dpi=300, bbox_inches='tight')
    
def continuePath(path, nodeIndex, endNode):
    
    if len(path[nodeIndex]["path"]) > 1:
        for i in path[nodeIndex]["path"]:
            return "," + str(continuePath(path, i, endNode))
    else:
        if path[nodeIndex]["path"] == endNode:
            return endNode
    
def keyNodePath(path, keyNodes):
    branch = []
    for i in range(0, len(keyNodes)-1):
        startNode = keyNodes[i]
        endNode = keyNodes[i+1]
        if (int(endNode) - int(startNode)) == 1:
            continue
        new_path = []
        for x in path[startNode]["path"]:
            if len(path[x]["path"]) == 1:
                if path[x]["path"][0] == endNode:
                    new_path.append(x)
                    continue
                else:
                    new_path2 = []
                    for y in path[x]["path"]:
                        if len(path[y]["path"]) == 1:
                            if path[y]["path"][0] == endNode:
                                new_path2.append(x)
                                new_path2.append(y)
                            else:
                                print("Shouldn't reach here")
                        else:
                            print("Shouldn't reach here")
                    new_path.append(new_path2)
            else:
                
                
                for y in path[x]["path"]:
                    new_path2 = []
                    print("Path3:" + str(path[y]["path"]))
                    if len(path[y]["path"]) == 1:
                        if path[y]["path"][0] == endNode:
                            new_path2.append(x)
                            new_path2.append(y)
                            print("newpath2:")
                            print(new_path2)
                        else:
                            print("Shouldn't reach here")
                    else:
                        print("Shouldn't reach here")
                    new_path.append(new_path2)    
        branch.append(new_path)
    print("KEYNODEPATH:")
    print(branch)
    return branch

def flattenList(l):
    i = 0
    t_list = l
    while i < len(t_list):
        if isinstance(t_list[i],list):
            temp = t_list[i]
            del t_list[i]
            index=i
            for x in temp:
                t_list.insert(index,x)
                index += 1
            i = index -1
        else:
            i += 1
    return t_list
    
def checkEnemiesBranch(path, battlelist, branch):
    print(path)
    print(branch)
    print(battlelist)
    bestPath = []
    badPath = []
    choicePath = []
    for b in branch:
        maxEnemies = 0
        bestStep = 0
        badPathT = []
        choicePathT = []
        for i in b:
            count = 0
            if isinstance(i, list):
                for i2 in i:
                    if path[i2]['type'] == "B":
                        count += battlelist[path[i2]['battleId']]
                        
            else:   
                if path[i]['type'] == "B":
                    count = battlelist[path[i]['battleId']]
            if count > maxEnemies:
                if bestStep != 0:
                    badPathT.append(bestStep)
                maxEnemies = count
                bestStep = i        
            elif count == 0 or count < maxEnemies:
                badPathT.append(i)
            elif count == maxEnemies:
                if bestStep != 0:
                    if not bestStep in choicePathT: choicePathT.append(bestStep)
                    choicePathT.append(i)
                    bestStep = i
        if maxEnemies == 0:
            choicePath.append(badPathT)
        else:
            for bad in badPathT:
                badPath.append(bad)
        pCount = {}
        layer1 = []
        layer2 = []
        
        for choice in choicePathT:
            i = 0
            for c in choice:
                if i == 0: 
                    if not c in layer1: layer1.append(c)
                elif i == 1:
                    if not c in layer2: layer2.append(c)
                i += 1
        if len(layer1) > 0 and len(layer2) > 0:
            if len(layer1) > 1:
                choicePath.append(layer1)
                bestPath.append(layer1)
            if len(layer1) == 1: 
                print("LAYER1: " + str(layer1))
                bestPath.append(layer1[0])
            if len(layer2) > 1:
                choicePath.append(layer2)
                bestPath.append(layer1)
            if len(layer2) == 1:
                print("LAYER2: " + str(layer2))
                bestPath.append(layer2[0])
        else:
            if bestStep == 0:
                bestPath.append(b)
            else:
                if isinstance(bestStep, list):
                    for best in bestStep:
                        bestPath.append(best)
                else:        
                    bestPath.append(bestStep)
    badPath = flattenList(badPath)
    #choicePath = flattenList(choicePath)
    #bestPath = flattenList(bestPath)
    return bestPath, choicePath, badPath
    
def createFullPath(path, bestPath):
    fullPath = []
    fullPath.append(0)
    step = 0
    print(path)
    print(t_bestPath)
    while step != len(path)-1:
        if len(path[step]["path"]) > 1:
            nextStep = bestPath.pop(0)
            if isinstance(nextStep, list):
                fullPath.append(-1)
                step = nextStep[0]
                    
            else:
                if not nextStep in fullPath: 
                    fullPath.append(nextStep)
                step = nextStep
            
        else:
            if not path[step]["path"][0] in fullPath: fullPath.append(path[step]["path"][0])
            step = path[step]["path"][0]
        
    return fullPath

def fullPathCount(path, fullPath, battlelist, choicePath):
    totalCount = 0
    print("CHOICEPATH:" + str(choicePath))
    for step in fullPath:
        if step == -1:
            choice = choicePath.pop(0)[0]
            if path[choice]['type'] == "B":
                totalCount += battlelist[path[choice]["battleId"]]
        elif path[step]['type'] == "B":
            totalCount += battlelist[path[step]["battleId"]]
    return totalCount

def makeColourMap(fullPath, choicePath, badPath, pathLen):
    colourMap = [None] * pathLen
    for f in fullPath:
        colourMap[f] = '#27F591'
    for c1 in choicePath:
        for c in c1:
            colourMap[c] = '#F59827'
    for b in badPath:
        colourMap[b] = '#E8565F'
    i = 0
    for c in colourMap:
        print(str(i) + ": " + str(c))
        i += 1
    #print(colourMap)
    return colourMap

rarity_dict = {}
G = nx.Graph()    
for tier in mow_dat["tiers"]:
    json_bat = tier["battles"]
    json_node = tier["nodes"]
    rarity = tier["rarity"]
    if rarity in rarity_dict:
        rarity_dict[rarity].append(len(rarity_dict[rarity]) + 1)
    else:
        rarity_dict[rarity] = [1]
    t_path, t_labels, t_keynodes = createNodes(json_node)
    print("TPATH:" + str(t_path))
    print("T_LABELS:" + str(t_labels))
    print("TKEYNODES:" + str(t_keynodes))
    t_bList = createBList(json_bat)
    t_branches = keyNodePath(t_path, t_keynodes)
    print("TBRANCHES:" + str(t_branches))
    t_bestPath, t_choicePath, t_badPath = checkEnemiesBranch(t_path, t_bList, t_branches)
    t_fullPath = createFullPath(t_path, t_bestPath)
    t_colourMap = makeColourMap(t_fullPath, t_choicePath, t_badPath, len(t_path))
    t_count = fullPathCount(t_path, t_fullPath, t_bList, t_choicePath)
    name = rarity + "-" +str(len(rarity_dict[rarity]) + ": " + str(t_count))
    createGraph(t_path, t_bList, t_labels, name, t_fullPath, t_colourMap)
    
#json_bat = mow_dat["tiers"][5]["battles"]
#json_node = mow_dat["tiers"][5]["nodes"]
#rarity = mow_dat["tiers"][5]["rarity"]
#t_bList = createBList(json_bat)
#t_path, t_labels, t_keynodes = createNodes(json_node)
#branches = keyNodePath(t_path, t_keynodes)
#t_bestPath, t_choicePath, t_badPath = checkEnemiesBranch(t_path, t_bList, branches)
#t_fullPath = createFullPath(t_path, t_bestPath)
#t_colourMap = makeColourMap(t_fullPath, t_choicePath, t_badPath, len(t_path))
#t_count = fullPathCount(t_path, t_fullPath, t_bList, t_choicePath)
#name = rarity + "1-" + str(t_count)
#createGraph(t_path, t_bList, t_labels, name, t_fullPath, t_colourMap)

