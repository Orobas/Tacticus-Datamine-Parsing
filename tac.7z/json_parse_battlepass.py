import json
with open('battle_pass.json', 'r') as file:
        dat = json.load(file)

def bpRewards(bp):
    rewards = {}
    for reward in bp:
        if ":" in reward["chestRewardId"]:
            reward_split = reward["chestRewardId"].split(":")
            item = reward_split[0]
            num = int(reward_split[1])
            if item in rewards:
                rewards[item] = int(rewards[item]) + num
            else:
                rewards[item] = num
        else:
            if reward["chestRewardId"] in rewards:
                rewards[reward["chestRewardId"]] = int(rewards[reward["chestRewardId"]]) + 1
            else:
                rewards[reward["chestRewardId"]] = 1
    return rewards

for bp in dat:
    print(bp)
    free = bpRewards(dat[bp]["free"])
    premium = bpRewards(dat[bp]["premium"])
    extra_premium = bpRewards(dat[bp]["extra_premium"])