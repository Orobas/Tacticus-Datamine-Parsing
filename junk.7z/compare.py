import json
import compareData
with open('battle_pass.json', 'r') as file:
    newBPDat = json.load(file)
with open('134battle_pass.json', 'r') as file:
    oldBPDat = json.load(file)
with open('135units.json', 'r') as file:
    newUDat = json.load(file)
with open('134units.json', 'r') as file:
    oldUDat = json.load(file)
uChanges = {}    
uChanges = compareData.compareTwo(oldUDat, newUDat)
bpChanges = {}
bpChanges = compareData.compareTwo(oldBPDat, newBPDat)
with open('unitsCompare.json', 'w') as w:
    json.dump(uChanges, w, indent=4)
with open('bpCompare.json', 'w') as w:
    json.dump(bpChanges, w, indent=4)